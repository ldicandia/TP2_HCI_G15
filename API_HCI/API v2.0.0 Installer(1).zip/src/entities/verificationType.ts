export enum VerificationType {
    REGISTRATION = "REGISTRATION",
    RESET_PASSWORD = "RESET_PASSWORD",
}
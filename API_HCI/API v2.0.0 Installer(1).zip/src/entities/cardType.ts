
export enum CardType {
    DEBIT = "DEBIT",
    CREDIT = "CREDIT",
}
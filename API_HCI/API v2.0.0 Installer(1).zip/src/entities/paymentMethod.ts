export enum PaymentMethod {
    ACCOUNT = "ACCOUNT",
    CARD = "CARD",
}
export type InvestmentDailyRateData = {
    interest: number;
}

export type InvestmentDailyReturnData = {
    id: number;
    return: number;
    date: string;
}